#include "Entities.h"

#include <gtc/matrix_transform.hpp>  
#include <gtc/type_ptr.hpp>

using namespace glm;

//-------------------------------------------------------------------------

void Entity::render(dmat4 const& modelViewMat) 
{ 
	setMvM(modelViewMat); 
	draw(); 
}
//-------------------------------------------------------------------------

void Entity::draw() 
{ 
  if (mesh != nullptr) 
    mesh -> draw(); 
}
//-------------------------------------------------------------------------

void Entity::setMvM(dmat4 const& modelViewMat)
{
	glMatrixMode(GL_MODELVIEW);
	dmat4 aMat = modelViewMat * modelMat;
	glLoadMatrixd(value_ptr(aMat));
}
//-------------------------------------------------------------------------

EjesRGB::EjesRGB(GLdouble l): Entity() 
{
  mesh = Mesh::generateAxesRGB(l);
}
//-------------------------------------------------------------------------

void EjesRGB::draw()
{
  glLineWidth(2);
  mesh->draw();
  glLineWidth(1);
}
//-------------------------------------------------------------------------
Triangulo::Triangulo(GLdouble r) : Entity()
{
	mesh = Mesh::generateTriangle(r);
}
//-------------------------------------------------------------------------

void Triangulo::draw()
{
	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	glLineWidth(2);
	//glcolor falta
	glColor3f(1.0, 0.0, 1.0);
	mesh->draw();
	//glLineWidth(1);
}
//-------------------------------------------------------------------------
TrianguloRGB::TrianguloRGB(GLdouble r) : Entity()
{
	mesh = Mesh::generateTriangleRGB(r);
}
//-------------------------------------------------------------------------

void TrianguloRGB::draw()
{
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);//Esto es necesario si genero el triangulo a lineas y este a la vez
	glLineWidth(2);
	//glcolor falta
	//glColor3f(1.0, 0.0, 1.0);
	mesh->draw();
	//glLineWidth(1);
}
//-------------------------------------------------------------------------
TriPyramid::TriPyramid(GLdouble r, GLdouble h) : Entity()
{
	mesh = Mesh::generateTriPyramid(r, h);
}
//-------------------------------------------------------------------------

void TriPyramid::draw()
{
	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	glLineWidth(2);
	//glcolor falta
	glColor3f(1.0, 0.0, 0.0);
	mesh->draw();
	//glLineWidth(1);
}
//-------------------------------------------------------------------------
ContCubo::ContCubo(GLdouble l) : Entity()
{
	mesh = Mesh::generateContCubo(l);
}
//-------------------------------------------------------------------------

void ContCubo::draw()
{
	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	glLineWidth(2);
	//glcolor falta
	glColor3f(0.0, 0.0, 0.0);
	mesh->draw();
	//glLineWidth(1);
}
//-------------------------------------------------------------------------
Diabolo::Diabolo(GLdouble r, GLdouble h) : Entity()
{
	this->r = r;
	this->h = h;
	mesh = Mesh::generateTriPyramid(this->r, this->h);
}
//-------------------------------------------------------------------------
void Diabolo::render(glm::dmat4 const& modelViewMat)
{
	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	glLineWidth(2);

	glColor3f(1.0, 0.0, 1.0);//rosa
	glTranslatef(0, 0, -h);//-200);
	glRotatef(angulo, 0, 0, 1); 
	mesh->draw();
	glColor3f(1.0, 0.5, 0.5);//naranja
	glRotatef(45, 0, 0, 1);
	glRotatef(angulo, 0, 0, 1);
	mesh->draw();

	glColor3f(0.0, 0.0, 0.0);//negro
	glScalef(1, 1, -1);
	glTranslatef(0, 0, -2 * h);//-400);
	glRotatef(angulo, 0, 0, 1);
	mesh->draw();
	glColor3f(0.5, 1.0, 1.0);//azul
	glRotatef(45, 0, 0, 1);
	glRotatef(angulo, 0, 0, 1);
	mesh->draw();
	//glLineWidth(1);
}
//-------------------------------------------------------------------------
void Diabolo::rota(){
	angulo += 3;
	//Rota pulsando a en el teclado como se indica en el main
}
//-------------------------------------------------------------------------
Rectangulo::Rectangulo(GLdouble w, GLdouble h) : Entity()
{
	mesh = Mesh::generateRectangle(w, h);
}
//-------------------------------------------------------------------------
void Rectangulo::draw()
{
	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	glLineWidth(2);
	//glcolor falta
	glColor3f(0.0, 0.0, 0.0);
	mesh->draw();
	//glLineWidth(1);
}
//-------------------------------------------------------------------------
Cubo::Cubo(GLdouble l) : Entity()
{
	mesh1 = Mesh::generateContCubo(l);
	mesh2 = Mesh::generateRectangle(l,l);
}
//-------------------------------------------------------------------------

void Cubo::render(glm::dmat4 const& modelViewMat)
{
	glPolygonMode(GL_FRONT, GL_LINE);
	glPolygonMode(GL_BACK, GL_POINT);
	//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	glLineWidth(2);
	//glcolor falta
	glColor3f(0.0, 0.0, 0.0);
	mesh1->draw();
	glTranslatef(0, 85, -15);//
	glRotatef(45, 1, 0, 0);
	//glRotatef(90, 0, 0, 1);
	mesh2->draw();
	//glLineWidth(1);
}