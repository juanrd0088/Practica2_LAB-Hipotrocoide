#include "Scene.h"

//-------------------------------------------------------------------------

void Scene::init()
{ // OpenGL basic setting
  glClearColor(1.0, 1.0, 1.0, 1.0);  // background color (alpha=1 -> opaque)
  glEnable(GL_DEPTH_TEST);  
  
  camera->setAZ();
    
  // lights
  // textures  

  // objets
  objetos.push_back(new EjesRGB(200.0));
  //objetos.push_back(new Triangulo(100.0));
  //objetos.push_back(new TrianguloRGB(100.0));
  //objetos.push_back(new TriPyramid(100.0,100.0));
  //objetos.push_back(new ContCubo(100.0));
  //El diabolo usa la funcion render en el display() del main que esta comentada, hay que descomentar para que renderice
	//el diabolo declarado como variable local tambien en el main
  //objetos.push_back(new Rectangulo(200.0, 100.0));
  //objetos.push_back(new Cubo(100.0));
  
}
//-------------------------------------------------------------------------

Scene::~Scene()
{ // free memory and resources 
  
  for each (Entity* it in objetos)
  {
	  delete it;
  }
}
//-------------------------------------------------------------------------

void Scene::render()
{
  glMatrixMode(GL_MODELVIEW);

	for each (Entity* it in objetos)
	{
		it->render(camera->getViewMat());

	}
  //Descomentar para la parte de los puertos de vista
  /*Viewport* puertoVista = camera->getVP();
  GLsizei oldw = puertoVista->getW();
  GLsizei oldh = puertoVista->getH();
  GLsizei oldx = puertoVista->getX();
  GLsizei oldy = puertoVista->getY();

  puertoVista->setSize(oldw/2, oldh/2);
  puertoVista->setPos(oldx, oldy);
  objetos[1]->render(camera->getViewMat());
  objetos[0]->render(camera->getViewMat());

  puertoVista->setSize(oldw / 2, oldh / 2);
  puertoVista->setPos(oldw/2, 0);
  objetos[2]->render(camera->getViewMat());
  objetos[0]->render(camera->getViewMat());

  puertoVista->setSize(oldw / 2, oldh / 2);
  puertoVista->setPos(0, oldh/2);
  objetos[3]->render(camera->getViewMat());
  objetos[0]->render(camera->getViewMat());

  puertoVista->setSize(oldw / 2, oldh / 2);
  puertoVista->setPos(oldw / 2, oldh / 2);
  objetos[4]->render(camera->getViewMat());
  objetos[0]->render(camera->getViewMat());

  //Restauro valores originales
  puertoVista->setSize(oldw, oldh);
  puertoVista->setPos(oldx, oldy);*/
	
}
//-------------------------------------------------------------------------
